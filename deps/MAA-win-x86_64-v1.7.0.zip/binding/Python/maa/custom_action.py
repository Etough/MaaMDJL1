import ctypes
from abc import ABC, abstractmethod

from .buffer import RectBuffer
from .context import SyncContext
from .define import *


class CustomAction(ABC):
    _handle: MaaCustomAction

    def __init__(self):
        self._handle = MaaCustomAction(self._c_run_agent, self._c_stop_agent)

    @abstractmethod
    def run(
        self,
        context: SyncContext,
        task_name: str,
        custom_param: str,
        box: Rect,
        rec_detail: str,
    ) -> bool:
        """
        Run the given action.

        :param context: The context.
        :param task_name: The name of the task.
        :param custom_param: The custom action param from pipeline.
        :param box: The current box.
        :param rec_detail: The current recognition detail.

        :return: return success or not
        """

        raise NotImplementedError

    @abstractmethod
    def stop(
        self,
    ) -> None:
        """
        Stop the given action.

        :return: None
        """

        raise NotImplementedError

    @property
    def c_handle(self) -> ctypes.POINTER(MaaCustomAction):
        return ctypes.pointer(self._handle)

    @property
    def c_arg(self) -> ctypes.c_void_p:
        return ctypes.c_void_p.from_buffer(ctypes.py_object(self))

    @MaaCustomAction.RunFunc
    def _c_run_agent(
        c_context: MaaSyncContextHandle,
        c_task_name: MaaStringView,
        c_custom_param: MaaStringView,
        c_box: MaaRectHandle,
        c_rec_detail: MaaStringView,
        c_transparent_arg: MaaTransparentArg,
    ) -> MaaBool:
        if not c_transparent_arg:
            return

        self: CustomAction = ctypes.cast(
            c_transparent_arg,
            ctypes.py_object,
        ).value

        context = SyncContext(c_context)
        task_name = c_task_name.decode("utf-8")
        custom_param = c_custom_param.decode("utf-8")

        box = RectBuffer(c_box).get()
        rec_detail = c_rec_detail.decode("utf-8")

        return self.run(
            context,
            task_name,
            custom_param,
            box,
            rec_detail,
        )

    @MaaCustomAction.StopFunc
    def _c_stop_agent(
        c_transparent_arg: MaaTransparentArg,
    ) -> None:
        if not c_transparent_arg:
            return

        self: CustomAction = ctypes.cast(
            c_transparent_arg,
            ctypes.py_object,
        ).value

        return self.stop()
